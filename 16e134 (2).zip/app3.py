from flask.app import Flask
from flask.globals import request, session
from flask.templating import render_template

app = Flask(__name__)
app.secret_key = '956495864uigoyuvgfhuvyhurf568r4e56'
@app.route('/')
@app.route('/result', methods=['GET', 'POST'])
def index():
    if request.method=='GET':
        return render_template('contact.html')
    if request.method=='POST':
        name=request.form
        session['user']=name["name"]
        session['address']=name["address"]
        return render_template('sucess.html')


if __name__ == '__main__':
    app.run(debug=True,port=1213)
    
    
