'''
Created on Nov 26, 2018

@author: PRAKASH ANAND
'''
from flask import Flask, request
from flask.templating import render_template
app=Flask(__name__)

@app.route('/service',methods=['GET','POST'])
def hello():
    if request.method=='GET':
        return render_template('service.html')
    elif request.method=='POST':
        return render_template('service.html')
if __name__ == "__main__":
    app.run(debug=True)