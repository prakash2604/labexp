'''
Created on Nov 26, 2018

@author: PRAKASH ANAND
'''

from flask import Flask
app=Flask(__name__)


@app.route('/hello')
def hello():
    return 'good morning'

@app.route('/hello/<username>')
def user(username):
    return 'good morning %s' %username

if __name__=='__main__':
    app.run(debug=True,port=1234,host='localhost')
